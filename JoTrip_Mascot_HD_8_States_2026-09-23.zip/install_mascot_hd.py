"""Install exact locked JoTrip mascot PNGs as 720px WebP derivatives.

Run from the repository root:
  python -m pip install Pillow
  python install_mascot_hd.py /path/to/JOTRIP_MASCOT_STATE_PACK_LOCKED_2026-09-22.zip

Original PNGs remain immutable inside the source archive. No AI generation/redrawing.
"""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
from PIL import Image
import argparse, hashlib, json

NAMES = [
    '01_greeting_wave', '02_listening', '03_thinking', '04_speaking',
    '05_guiding_map', '06_compare_two_directions',
    '07_checking_phone_review', '08_confirm_thumbs_up',
]
SHA256 = [
    '96f376e65d4602a092a2954ebab7ce62bb8f9191c0afbf69b4e31465c450eb40',
    'c94b5f6666028778907c8c971828a369487a7e35642d36828d6e725100e6384e',
    '0b9ed610c8751fddf0f50632b3e31c2090c0f30ee17fc8c5f73fe18b4ff72df6',
    '6cd88956b453a35199a825ffb73adbb518f72553ca1b8f4614d6f5aef145bd46',
    '9b0545482403616616e80ecacdb77730d86b6821ec8dbb36c06ca341401f9b10',
    '1d3b5ea9bcd5aba10e72809d40863eac5d7a6e7b9f317b9d3f67d6c52370d89e',
    '8501ef15257663c937740c46d06cac30c5fc076fd58d3ad014cbdbab5048ddc8',
    'ee6d73d07d609b303df771c1be39c83103b9bafcd50fd984a9ff2b85e7c2110c',
]

def install(source: Path, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    completed = []
    with ZipFile(source) as pack:
        for name, expected in zip(NAMES, SHA256):
            members = [m for m in pack.namelist() if m.endswith('/' + name + '.png')]
            if len(members) != 1:
                raise ValueError('Missing or duplicate canonical PNG: ' + name)
            data = pack.read(members[0])
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError('Canonical SHA256 mismatch: ' + name)
            src = Image.open(BytesIO(data)).convert('RGBA')
            if src.size != (1122, 1402):
                raise ValueError('Unexpected original dimensions: ' + name)
            dst = output / (name + '_hd.webp')
            src.resize((720, 900), Image.Resampling.LANCZOS).save(dst, 'WEBP', quality=78, method=3)
            if Image.open(dst).size != (720, 900):
                raise ValueError('HD derivative verification failed: ' + name)
            completed.append({'state': name, 'file': dst.name, 'bytes': dst.stat().st_size,
                              'source_sha256': expected,
                              'sha256': hashlib.sha256(dst.read_bytes()).hexdigest()})
    (output / 'hd-manifest.json').write_text(json.dumps({'version': '2026-09-23',
        'source': source.name, 'method': 'Exact canonical PNG -> LANCZOS WebP 720x900 quality 78',
        'assets': completed}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('Verified locked source 8/8; created HD WebP 8/8 in', output)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_zip', type=Path)
    parser.add_argument('--out', type=Path, default=Path('public/assets/mascot-v1'))
    args = parser.parse_args()
    install(args.source_zip, args.out)
